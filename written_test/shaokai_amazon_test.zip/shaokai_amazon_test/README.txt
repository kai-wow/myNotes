1. Programming Quiz
所有答案（包括代码）都写入了 word 文件 '1.Programming Quiz.docx' 中。
另外，题目中涉及的 python 部分的代码可以在 '1.1Python_answer(part).py' 中获取并运行；
题目中涉及的 R 部分的代码可以在 '1.2R_answer.R' 中获取并运行。

2. SQL Quiz
所有答案（包括代码）都写入了 word 文件 '2.SQL Quiz.docx' 中。

3. VBA test
答案见 '3.VBA Test\Output Sheet Templates.xls' 表格内容，
相关 VBA 代码可在此表格的 Visual Basic 中查看，同时也可从 '3.VBA Test\3.1vba_answer.cls' 文件查看。